// offscreen.js — ページ全体画像から要素部分を Canvas で切り抜き、クリップボードへ書き込む
'use strict';

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen') return; // 他宛てのメッセージは無視
  if (msg.type === 'crop-copy') {
    cropAndCopy(msg).then(sendResponse, (e) =>
      sendResponse({ ok: false, error: e?.message || String(e) })
    );
    return true; // 非同期で応答
  }
});

/**
 * @param base64     captureScreenshot の PNG（Base64）
 * @param sourceCss  画像が表す範囲の CSS サイズ {w, h}（ページ全体なら pageW × captureH）
 * @param crop       切り抜く範囲（sourceCss と同じ座標系の CSS px）{x, y, width, height}
 * @param strict     true: 画像サイズが sourceCss と食い違う場合は切り抜かず mismatch を返す
 * @param targetWidth 出力幅（物理px）。null なら等倍
 */
async function cropAndCopy({ base64, sourceCss, crop, strict, targetWidth }) {
  const img = await createImageBitmap(b64ToBlob(base64, 'image/png'));
  let blob, outW, outH;
  try {
    // 倍率 = 実際の画像ピクセル ÷ CSS ピクセル（DPR・Windows拡大率・ズームを自動的に吸収）
    const scaleX = img.width / sourceCss.w;
    const scaleY = img.height / sourceCss.h;

    // 縦横の倍率が食い違う = captureBeyondViewport が効かず画面1枚分しか撮れていない
    if (strict && Math.abs(scaleX - scaleY) / Math.max(scaleX, scaleY) > 0.03) {
      return { ok: false, mismatch: true, image: { w: img.width, h: img.height }, sourceCss };
    }

    // 左上・右下の端をそれぞれ物理 px に丸める（1px のズレ・にじみを防ぐ）
    const clampX = (v) => Math.min(Math.max(v, 0), img.width);
    const clampY = (v) => Math.min(Math.max(v, 0), img.height);
    const sx = clampX(Math.round(crop.x * scaleX));
    const sy = clampY(Math.round(crop.y * scaleY));
    const sw = clampX(Math.round((crop.x + crop.width) * scaleX)) - sx;
    const sh = clampY(Math.round((crop.y + crop.height) * scaleY)) - sy;
    if (sw < 1 || sh < 1) throw new Error('切り抜き範囲が画像の外にあります');

    outW = sw;
    outH = sh;
    if (targetWidth && targetWidth !== sw) {
      outW = Math.max(1, Math.round(targetWidth));
      outH = Math.max(1, Math.round(sh * (outW / sw)));
    }

    const canvas = new OffscreenCanvas(outW, outH);
    const ctx = canvas.getContext('2d');
    if (outW === sw) {
      ctx.imageSmoothingEnabled = false; // 等倍転写は補間しない
    } else {
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
    }
    ctx.drawImage(img, sx, sy, sw, sh, 0, 0, outW, outH);
    blob = await canvas.convertToBlob({ type: 'image/png' });
  } finally {
    img.close();
  }

  try {
    try { window.focus(); } catch (_) {}
    await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
    return { ok: true, width: outW, height: outH };
  } catch (e) {
    // offscreen はフォーカスを持てず失敗する環境がある → 切り抜き済み画像を返してページ側で再試行
    return {
      ok: false,
      error: e?.message || String(e),
      base64: await blobToBase64(blob),
      width: outW,
      height: outH,
    };
  }
}

function b64ToBlob(b64, type) {
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return new Blob([u8], { type });
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1]);
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}
