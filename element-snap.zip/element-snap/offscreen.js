// offscreen.js — Base64 PNG の処理（必要に応じ Canvas でリサイズ）とクリップボード書き込み
'use strict';

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen') return; // 他宛てのメッセージは無視
  if (msg.type === 'copy-png') {
    copyPng(msg).then(sendResponse, (e) =>
      sendResponse({ ok: false, error: e?.message || String(e) })
    );
    return true; // 非同期で応答
  }
});

async function copyPng({ base64, targetWidth }) {
  const bytes = b64ToBytes(base64);
  let { width, height } = pngSize(bytes);
  let blob = new Blob([bytes], { type: 'image/png' });
  let processedBase64 = null;

  // 出力倍率が指定されている場合のみ Canvas でリサイズ
  // （CDP の出力は既に PNG のため、不要な再エンコードは避ける）
  if (targetWidth && targetWidth !== width) {
    const w = Math.max(1, Math.round(targetWidth));
    const h = Math.max(1, Math.round(height * (w / width)));
    blob = await resizeWithCanvas(blob, w, h);
    width = w;
    height = h;
    processedBase64 = await blobToBase64(blob);
  }

  try {
    await writeImageToClipboard(blob);
    return { ok: true, width, height };
  } catch (e) {
    // offscreen ドキュメントはフォーカスを持たないため失敗する環境がある。
    // background → ページ側で再試行できるよう、加工後の画像を返す。
    return {
      ok: false,
      error: e?.message || String(e),
      base64: processedBase64, // null の場合 background は元データを使う
      width,
      height,
    };
  }
}

async function writeImageToClipboard(blob) {
  if (!navigator.clipboard || !window.ClipboardItem) {
    throw new Error('Clipboard API が利用できません');
  }
  try { window.focus(); } catch (_) {}
  await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
}

async function resizeWithCanvas(blob, w, h) {
  const bmp = await createImageBitmap(blob);
  try {
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(bmp, 0, 0, w, h);
    return await new Promise((resolve, reject) =>
      canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('Canvas の PNG 変換に失敗しました'))), 'image/png')
    );
  } finally {
    bmp.close();
  }
}

function b64ToBytes(b64) {
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

function pngSize(u8) {
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  return { width: dv.getUint32(16), height: dv.getUint32(20) };
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1]);
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}
