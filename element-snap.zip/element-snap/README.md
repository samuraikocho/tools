# Element Snap Clipper（Microsoft Edge / Manifest V3）

Webページ上の任意の要素をクリックするだけで、その要素の領域を高精度にキャプチャしてクリップボードへコピーする拡張機能です。
Shadow DOM（closed を含む）の中の要素も選択できます。

## インストール（動作確認）
1. `edge://extensions` を開く
2. 左下の「開発者モード」をオン
3. 「展開して読み込み」でこのフォルダ（`manifest.json` があるフォルダ）を選択

## 使い方
| 操作 | 内容 |
|---|---|
| ツールバーのアイコン / `Alt+Shift+S` | 要素選択モードの開始・終了 |
| マウスを合わせる | 要素をハイライト（タグ名#id.class とサイズを表示） |
| クリック / `Enter` | ハイライト中の要素をキャプチャしてコピー |
| `↑` (`W`) / `↓` (`S`) | 親要素へ広げる / 子要素へ戻る（Shadow DOM の境界はホスト要素へ） |
| `Esc` | キャンセル |

選択モードを開始すると、Edge 上部に「デバッグを開始しました」のバーが表示されます（`chrome.debugger` の仕様上必ず表示されます）。

## 仕組み
- **要素の特定**: `DOM.getNodeForLocation`（CDP）で Shadow DOM を貫通して取得。オーバーレイは `pointer-events:none` + `ignorePointerEventsNone:true` で判定対象から除外。
- **矩形の取得**: `DOM.getBoxModel`（取れない場合は `DOM.getContentQuads`）。
- **アタッチの最適化**: モード開始の瞬間に `chrome.debugger.attach()` を content script 注入・offscreen 生成と並列実行。終了後も 5 分間は接続を維持し、再開を高速化。
- **一発キャプチャ**: `Page.captureScreenshot` に clip を渡して 1 回で取得。要素が画面外にはみ出す場合は `captureBeyondViewport: true`。
- **クリップボード**: offscreen ドキュメントで `navigator.clipboard.write()`。offscreen はフォーカスを持てず失敗する環境があるため、失敗時はフォーカスのあるページ側（content script）で自動的に再試行。

## 設定（background.js 冒頭の `CONFIG`）
- `captureBeyondViewport`: `'auto'`（既定・はみ出す時だけ true）／ `true`（常に true）
- `outputScale`: `null`（デバイス解像度のまま）／ `1`（CSS px 等倍に縮小）など。指定時は offscreen の Canvas でリサイズ
- `idleDetachMs`: 選択モード終了後に debugger を切断するまでの時間

## 既知の制限
- `edge://` ページや拡張機能ストアなど、拡張機能が動作できないページでは使えません。
- `captureBeyondViewport` は一時的にビューポートを拡張するため、100vh 固定レイアウト（Salesforce Lightning など）では、はみ出し部分を撮る際に再レイアウトの影響を受けることがあります。
- ページ全体ではなく内部のスクロールコンテナ内で隠れている部分は、`captureBeyondViewport` でも写りません（コンテナのスクロール位置にある見えている部分のみ）。
- iframe 内（特にクロスオリジン iframe / Visualforce 等）の要素選択には対応していません。
- ブラウザのズームは 100% での利用を推奨します。
- 非常に長い要素（目安: 高さ 16,000px 超）は GPU の制限で失敗・欠ける場合があります。
