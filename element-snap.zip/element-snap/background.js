// background.js — Service Worker
// 役割: debugger (CDP) の接続管理 / 要素の特定・矩形取得 / スクリーンショット / offscreen との中継
'use strict';

/* ============================================================
 * 設定
 * ============================================================ */
const CONFIG = {
  // 'auto' : 要素がビューポートからはみ出す時だけ captureBeyondViewport:true を使う（推奨）
  // true   : 常に captureBeyondViewport:true
  //   ※ true は一時的にビューポートを拡張するため、100vh レイアウトのSPAで
  //     画面内の要素まで再レイアウトの影響を受けることがある。そのため既定は 'auto'。
  captureBeyondViewport: 'auto',

  // 出力倍率。null = デバイス解像度のまま（高DPI環境ではより高精細）
  //           1    = CSSピクセル等倍に縮小 / 2 = 2倍 など（offscreen の Canvas でリサイズ）
  outputScale: null,

  // 選択モード終了後、この時間操作がなければ debugger を切断（再開時の高速化のため即切断しない）
  idleDetachMs: 5 * 60 * 1000,
};

const PROTOCOL_VERSION = '1.3';
const PORT_NAME = 'element-snap';
const OBJECT_GROUP = 'element-snap';

/** tabId -> { ready: Promise<void>, timer: number|null } */
const debuggees = new Map();
/** tabId -> session */
const sessions = new Map();

// DOM.getNodeForLocation の座標系（ビューポート基準 / ドキュメント基準）を
// スクロール時に自動判定してキャッシュする（Chromium のバージョン差異対策）
let coordMode = null; // null | 'viewport' | 'document'

const cdp = (tabId, method, params = {}) =>
  chrome.debugger.sendCommand({ tabId }, method, params);

/* ============================================================
 * アクション（アイコン / ショートカット）
 * ============================================================ */
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || tab.id == null) return;
  const tabId = tab.id;

  // 選択モード中ならトグルで終了
  const existing = sessions.get(tabId);
  if (existing) {
    post(existing, { type: 'stop' });
    return;
  }

  // ★ モード開始の瞬間に debugger をアタッチ（content script 注入・offscreen 生成と並列）
  const attachP = ensureAttached(tabId);
  attachP.catch(() => {}); // エラーは onConnect 側で通知
  ensureOffscreen().catch((e) => console.warn('[ElementSnap] offscreen 事前生成失敗:', e));

  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
  } catch (e) {
    console.warn('[ElementSnap] content script を注入できません:', e.message);
    flashBadge(tabId, '×', '#c5221f');
    scheduleDetach(tabId);
  }
});

/* ============================================================
 * content script との通信（長寿命ポート）
 * ============================================================ */
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== PORT_NAME) return;
  const tabId = port.sender?.tab?.id;
  if (tabId == null || port.sender.frameId !== 0) {
    port.disconnect();
    return;
  }

  const old = sessions.get(tabId);
  if (old) {
    try { old.port.disconnect(); } catch (_) {}
  }

  const session = {
    tabId,
    port,
    hoverId: null,   // マウス直下の要素
    currentId: null, // 現在選択中の要素（↑キーで親へ移動した結果を含む）
    stack: [],       // ↓キーで戻るための履歴
    labels: new Map(),
    busy: false,
  };
  sessions.set(tabId, session);
  cancelDetach(tabId);
  setBadge(tabId, 'ON', '#0b6cff');

  ensureAttached(tabId).catch((err) =>
    post(session, { type: 'error', message: 'デバッガに接続できません: ' + err.message })
  );

  port.onMessage.addListener((msg) => {
    handleMessage(session, msg).catch((e) => console.error('[ElementSnap]', e));
  });

  port.onDisconnect.addListener(() => {
    if (sessions.get(tabId) === session) sessions.delete(tabId);
    setBadge(tabId, '');
    try { cdp(tabId, 'Runtime.releaseObjectGroup', { objectGroup: OBJECT_GROUP }).catch(() => {}); } catch (_) {}
    scheduleDetach(tabId);
  });
});

function post(session, msg) {
  try { session.port.postMessage(msg); } catch (_) { /* ポート切断済み */ }
}

async function handleMessage(s, msg) {
  switch (msg?.type) {
    case 'hover':   return onHover(s, msg);
    case 'parent':  return onParent(s, msg);
    case 'child':   return onChild(s, msg);
    case 'capture': return onCapture(s, msg);
  }
}

/* ============================================================
 * ホバー / 親子移動
 * ============================================================ */
async function onHover(s, { seq, x, y, sx, sy }) {
  let id = null;
  let rect = null;
  try {
    await ensureAttached(s.tabId);
    ({ id, rect } = await resolveAt(s.tabId, x, y, sx, sy));
  } catch (_) {}

  if (!id) {
    s.hoverId = s.currentId = null;
    s.stack = [];
    post(s, { type: 'highlight', kind: 'hover', seq, rect: null });
    return;
  }

  // マウス直下の要素が変わった時だけ選択をリセット（↑で選んだ親を微小なマウス移動で失わないため）
  if (id !== s.hoverId) {
    s.hoverId = id;
    s.currentId = id;
    s.stack = [];
  }
  await sendHighlight(s, 'hover', seq, s.currentId === id ? rect : null);
}

async function onParent(s, { seq }) {
  if (s.currentId) {
    const pid = await getParentId(s.tabId, s.currentId);
    if (pid) {
      s.stack.push(s.currentId);
      s.currentId = pid;
    }
  }
  await sendHighlight(s, 'key', seq);
}

async function onChild(s, { seq }) {
  if (s.stack.length) s.currentId = s.stack.pop();
  await sendHighlight(s, 'key', seq);
}

async function sendHighlight(s, kind, seq, knownRect = null) {
  const id = s.currentId;
  if (!id) {
    post(s, { type: 'highlight', kind, seq, rect: null });
    return;
  }
  const [rect, label] = await Promise.all([
    knownRect ? Promise.resolve(knownRect) : getRect(s.tabId, id),
    getLabel(s, id),
  ]);
  post(s, { type: 'highlight', kind, seq, rect, label });
}

/* ============================================================
 * キャプチャ
 * ============================================================ */
async function onCapture(s, { x, y, sx, sy }) {
  if (s.busy) return;
  s.busy = true;
  try {
    await ensureAttached(s.tabId);

    let id = s.currentId;
    if (!id) ({ id } = await resolveAt(s.tabId, x, y, sx, sy));
    if (!id) throw new Error('要素が見つかりません');

    const rect = await getRect(s.tabId, id);
    if (!rect || rect.width < 1 || rect.height < 1) {
      throw new Error('要素のサイズを取得できません（非表示要素の可能性があります）');
    }

    const { clip, beyond } = await computeClip(s.tabId, rect);

    // ★ 1回のコマンドで一発キャプチャ（画面外にはみ出す要素は captureBeyondViewport:true）
    const { data } = await cdp(s.tabId, 'Page.captureScreenshot', {
      format: 'png',
      clip,
      captureBeyondViewport: beyond,
      fromSurface: true,
    });
    post(s, { type: 'captured' });

    const targetWidth = CONFIG.outputScale
      ? Math.max(1, Math.round(clip.width * CONFIG.outputScale))
      : null;

    // offscreen ドキュメントでクリップボードへ書き込み
    let res;
    try {
      await ensureOffscreen();
      res = await chrome.runtime.sendMessage({
        target: 'offscreen',
        type: 'copy-png',
        base64: data,
        targetWidth,
      });
    } catch (e) {
      res = { ok: false, error: e.message };
    }

    if (res && res.ok) {
      post(s, { type: 'result', ok: true, width: res.width, height: res.height });
    } else {
      // offscreen はフォーカスを持てず失敗する環境があるため、
      // ユーザーがクリックした直後でフォーカスのあるページ側で書き込みを再試行する
      console.warn('[ElementSnap] offscreen でのコピー失敗 → ページ側で再試行:', res?.error);
      post(s, {
        type: 'clipboard-fallback',
        base64: (res && res.base64) || data,
        reason: res?.error,
      });
    }
  } catch (e) {
    post(s, { type: 'result', ok: false, error: e.message || String(e) });
  } finally {
    s.busy = false;
  }
}

/** 要素のビューポート座標の矩形 → captureScreenshot 用の clip（ドキュメント座標） */
async function computeClip(tabId, rect) {
  const m = await cdp(tabId, 'Page.getLayoutMetrics');
  const vv = m.cssVisualViewport || m.visualViewport;
  const lv = m.cssLayoutViewport || m.layoutViewport;
  const cs = m.cssContentSize || m.contentSize;

  const pageX = vv.pageX || 0;
  const pageY = vv.pageY || 0;
  const vw = lv.clientWidth;
  const vh = lv.clientHeight;
  const maxW = Math.max(cs.width, pageX + vw);
  const maxH = Math.max(cs.height, pageY + vh);

  const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), hi);
  const x0 = clamp(Math.floor(rect.x + pageX), 0, maxW);
  const y0 = clamp(Math.floor(rect.y + pageY), 0, maxH);
  const x1 = clamp(Math.ceil(rect.x + rect.width + pageX), 0, maxW);
  const y1 = clamp(Math.ceil(rect.y + rect.height + pageY), 0, maxH);
  if (x1 - x0 < 1 || y1 - y0 < 1) throw new Error('要素がページ範囲外です');

  const tol = 0.5;
  const outside =
    rect.x < -tol || rect.y < -tol ||
    rect.x + rect.width > vw + tol || rect.y + rect.height > vh + tol;

  const beyond =
    CONFIG.captureBeyondViewport === true ||
    (CONFIG.captureBeyondViewport === 'auto' && outside);

  return { clip: { x: x0, y: y0, width: x1 - x0, height: y1 - y0, scale: 1 }, beyond };
}

/* ============================================================
 * CDP ヘルパー（要素特定・矩形・ラベル・親要素）
 * ============================================================ */

/** Shadow DOM（closed 含む）を貫通して座標直下の要素を取得 */
async function nodeAt(tabId, x, y) {
  const { backendNodeId } = await cdp(tabId, 'DOM.getNodeForLocation', {
    x: Math.round(x),
    y: Math.round(y),
    includeUserAgentShadowDOM: false, // <input> 内部などUA Shadowは除外し、ホスト要素を返す
    ignorePointerEventsNone: true,    // 本拡張のオーバーレイ (pointer-events:none) を無視
  });
  return backendNodeId || null;
}

async function nodeWithRect(tabId, x, y) {
  const id = await nodeAt(tabId, x, y).catch(() => null);
  return { id, rect: id ? await getRect(tabId, id) : null };
}

const containsPoint = (r, x, y) =>
  !!r && x >= r.x - 1 && x <= r.x + r.width + 1 && y >= r.y - 1 && y <= r.y + r.height + 1;

/**
 * clientX/Y から要素を特定。
 * ページがスクロールされている場合、getNodeForLocation の座標系を一度だけ自動判定する。
 */
async function resolveAt(tabId, x, y, sx = 0, sy = 0) {
  const scrolled = Math.abs(sx) >= 1 || Math.abs(sy) >= 1;
  if (!scrolled || coordMode === 'viewport') {
    return { id: await nodeAt(tabId, x, y).catch(() => null) };
  }
  if (coordMode === 'document') {
    return { id: await nodeAt(tabId, x + sx, y + sy).catch(() => null) };
  }
  const [a, b] = await Promise.all([
    nodeWithRect(tabId, x, y),
    nodeWithRect(tabId, x + sx, y + sy),
  ]);
  const inA = containsPoint(a.rect, x, y);
  const inB = containsPoint(b.rect, x, y);
  if (inA && !inB) coordMode = 'viewport';
  else if (inB && !inA) coordMode = 'document';
  return coordMode === 'document' ? b : a;
}

/** 要素の border-box 矩形（メインフレームのビューポート座標, CSS px） */
async function getRect(tabId, backendNodeId) {
  try {
    const { model } = await cdp(tabId, 'DOM.getBoxModel', { backendNodeId });
    return quadsBounds([model.border]);
  } catch (_) {
    // display:contents 等で box model が取れない場合は content quads で代替
    try {
      const { quads } = await cdp(tabId, 'DOM.getContentQuads', { backendNodeId });
      if (quads && quads.length) return quadsBounds(quads);
    } catch (_) {}
    return null;
  }
}

function quadsBounds(quads) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const q of quads) {
    for (let i = 0; i < q.length; i += 2) {
      minX = Math.min(minX, q[i]);
      maxX = Math.max(maxX, q[i]);
      minY = Math.min(minY, q[i + 1]);
      maxY = Math.max(maxY, q[i + 1]);
    }
  }
  if (!isFinite(minX)) return null;
  return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
}

async function getLabel(s, id) {
  if (s.labels.has(id)) return s.labels.get(id);
  let label = '';
  try {
    const { node } = await cdp(s.tabId, 'DOM.describeNode', { backendNodeId: id });
    label = buildLabel(node);
  } catch (_) {}
  s.labels.set(id, label);
  return label;
}

function buildLabel(node) {
  if (node.pseudoType) return '::' + node.pseudoType;
  const attrs = {};
  const a = node.attributes || [];
  for (let i = 0; i + 1 < a.length; i += 2) attrs[a[i]] = a[i + 1];
  let t = (node.localName || node.nodeName || '').toLowerCase();
  if (attrs.id) t += '#' + attrs.id;
  if (attrs.class) {
    t += attrs.class.trim().split(/\s+/).filter(Boolean).slice(0, 3).map((c) => '.' + c).join('');
  }
  return t.length > 80 ? t.slice(0, 79) + '…' : t;
}

// ページ側で実行される関数: 親要素を返す（Shadow DOM の境界はホスト要素へ、display:contents はスキップ）
const PARENT_FN = function () {
  let el = this;
  for (;;) {
    let p = el.parentElement;
    if (!p) {
      const r = el.parentNode;
      p = r && r.nodeType === 11 && r.host ? r.host : null;
    }
    if (!p) {
      try { p = el.ownerDocument.defaultView.frameElement; } catch (e) { p = null; }
    }
    if (!p) return null;
    el = p;
    const view = el.ownerDocument.defaultView || window;
    if (view.getComputedStyle(el).display !== 'contents') return el;
  }
}.toString();

async function getParentId(tabId, backendNodeId) {
  try {
    const { object } = await cdp(tabId, 'DOM.resolveNode', { backendNodeId, objectGroup: OBJECT_GROUP });
    const { result } = await cdp(tabId, 'Runtime.callFunctionOn', {
      objectId: object.objectId,
      functionDeclaration: PARENT_FN,
      objectGroup: OBJECT_GROUP,
    });
    if (result.subtype !== 'node' || !result.objectId) return null;
    const { node } = await cdp(tabId, 'DOM.describeNode', { objectId: result.objectId });
    return node.backendNodeId || null;
  } catch (_) {
    return null;
  } finally {
    cdp(tabId, 'Runtime.releaseObjectGroup', { objectGroup: OBJECT_GROUP }).catch(() => {});
  }
}

/* ============================================================
 * debugger 接続管理（モード開始時にアタッチし、しばらく接続を維持）
 * ============================================================ */
function ensureAttached(tabId) {
  const existing = debuggees.get(tabId);
  if (existing) {
    clearTimeout(existing.timer);
    existing.timer = null;
    return existing.ready;
  }

  const entry = { timer: null, ready: null };
  entry.ready = (async () => {
    try {
      await chrome.debugger.attach({ tabId }, PROTOCOL_VERSION);
    } catch (e) {
      if (!/already attached/i.test(e?.message || '')) throw e;
      // Service Worker 再起動後など、自分の接続が残っている場合はそのまま使う
      // （他の拡張機能の接続であればここで例外になる）
      await cdp(tabId, 'Runtime.evaluate', { expression: '1' });
    }
  })();
  entry.ready.catch(() => {
    if (debuggees.get(tabId) === entry) debuggees.delete(tabId);
  });
  debuggees.set(tabId, entry);
  return entry.ready;
}

function scheduleDetach(tabId) {
  const entry = debuggees.get(tabId);
  if (!entry) return;
  clearTimeout(entry.timer);
  entry.timer = setTimeout(() => {
    if (sessions.has(tabId)) return;
    debuggees.delete(tabId);
    chrome.debugger.detach({ tabId }).catch(() => {});
  }, CONFIG.idleDetachMs);
}

function cancelDetach(tabId) {
  const entry = debuggees.get(tabId);
  if (entry) {
    clearTimeout(entry.timer);
    entry.timer = null;
  }
}

chrome.debugger.onDetach.addListener((source, reason) => {
  const tabId = source.tabId;
  if (tabId == null) return;
  const entry = debuggees.get(tabId);
  if (entry) clearTimeout(entry.timer);
  debuggees.delete(tabId);

  const s = sessions.get(tabId);
  if (s) {
    post(s, {
      type: 'error',
      message: reason === 'canceled_by_user'
        ? 'デバッグ接続がキャンセルされました'
        : 'デバッガが切断されました (' + reason + ')',
    });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  const entry = debuggees.get(tabId);
  if (entry) clearTimeout(entry.timer);
  debuggees.delete(tabId);
  sessions.delete(tabId);
});

/* ============================================================
 * offscreen ドキュメント
 * ============================================================ */
let creatingOffscreen = null;

async function ensureOffscreen() {
  const url = chrome.runtime.getURL('offscreen.html');
  if (chrome.runtime.getContexts) {
    const ctx = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [url],
    });
    if (ctx.length) return;
  }
  if (!creatingOffscreen) {
    creatingOffscreen = chrome.offscreen
      .createDocument({
        url: 'offscreen.html',
        reasons: ['CLIPBOARD'],
        justification: 'キャプチャした画像をクリップボードへコピーするため',
      })
      .catch((e) => {
        if (!/single offscreen|already/i.test(e?.message || '')) throw e;
      })
      .finally(() => {
        creatingOffscreen = null;
      });
  }
  await creatingOffscreen;
}

/* ============================================================
 * バッジ
 * ============================================================ */
function setBadge(tabId, text, color) {
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
  if (color) chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {});
}

function flashBadge(tabId, text, color) {
  setBadge(tabId, text, color);
  setTimeout(() => setBadge(tabId, ''), 2000);
}
