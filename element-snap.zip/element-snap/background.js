// background.js — Service Worker (v1.2)
// 役割: content script の注入 / クリック時だけ debugger をアタッチして撮影 → 即デタッチ / offscreen との中継
'use strict';

/* ============================================================
 * 設定
 * ============================================================ */
const CONFIG = {
  // 画面外にはみ出す要素を撮る時の、ページ画像の最大高さ（CSS px）。GPU 上限対策
  maxCaptureCssHeight: 16000,
  // 出力倍率。null = デバイス解像度のまま / 1 = CSS px 等倍 / 2 = 2倍
  outputScale: null,
  // アタッチ後に撮影要求が来なかった場合の安全デタッチ（ms）
  safetyDetachMs: 15000,
};

const PROTOCOL_VERSION = '1.3';

/** tabId -> { ready: Promise<void>, timer: number } */
const attached = new Map();

const cdp = (tabId, method, params = {}) =>
  chrome.debugger.sendCommand({ tabId }, method, params);

/* ============================================================
 * アイコン / ショートカット
 * ============================================================ */
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || tab.id == null) return;
  ensureOffscreen().catch((e) => console.warn('[ElementSnap] offscreen 事前生成失敗:', e));
  try {
    // 2回目以降の注入は content.js 側で開始 / 終了をトグル
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
  } catch (e) {
    console.warn('[ElementSnap] このページでは実行できません:', e.message);
    setBadge(tab.id, '×', '#c5221f');
    setTimeout(() => setBadge(tab.id, ''), 2000);
  }
});

/* ============================================================
 * content script からの要求
 * ============================================================ */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target === 'offscreen' || !sender.tab) return;
  handle(msg, sender.tab).then(sendResponse, (e) =>
    sendResponse({ ok: false, error: e?.message || String(e) })
  );
  return true;
});

async function handle(msg, tab) {
  const tabId = tab.id;
  switch (msg.type) {
    case 'mode':
      setBadge(tabId, msg.on ? 'ON' : '', '#0b6cff');
      return { ok: true };

    case 'attach':
      // ★ クリックされた瞬間にだけアタッチ
      await ensureAttached(tabId);
      return { ok: true };

    case 'capture':
      try {
        return await doCapture(tabId, msg);
      } finally {
        // ★ 撮影が終わったら（成功・失敗にかかわらず）直ちにデタッチ
        await detach(tabId);
      }

    case 'detach':
      await detach(tabId);
      return { ok: true };
  }
  return { ok: false, error: 'unknown message' };
}

/* ============================================================
 * 撮影
 * ============================================================ */
async function doCapture(tabId, { viewRect, pageRect, viewport, dpr }) {
  await ensureAttached(tabId);
  if (!viewRect || viewRect.width < 1 || viewRect.height < 1) {
    throw new Error('要素の座標が不正です');
  }

  const tol = 0.5;
  const inView =
    viewRect.x >= -tol &&
    viewRect.y >= -tol &&
    viewRect.x + viewRect.width <= viewport.cw + tol &&
    viewRect.y + viewRect.height <= viewport.ch + tol;

  if (inView) {
    // ★ 画面内に収まる要素: captureBeyondViewport を使わない。
    //   ビューポートの拡張が起きないため、スクロール位置は一切変わらない
    const { data } = await cdp(tabId, 'Page.captureScreenshot', { format: 'png', fromSurface: true });
    const img = pngSizeFromBase64(data);
    const expectedW = viewport.w * dpr;
    // 画像は物理 px。DPR から想定される幅と一致すれば DPR を倍率として使う（スクロールバー幅の誤差を吸収）
    const sourceCss =
      Math.abs(img.width - expectedW) <= Math.max(2, expectedW * 0.03)
        ? { w: img.width / dpr, h: img.height / dpr }
        : { w: viewport.w, h: viewport.h };
    return await cropOnOffscreen({ base64: data, sourceCss, crop: viewRect, strict: false });
  }

  // 画面外にはみ出す要素: ページ全体を原点(0,0)から captureBeyondViewport:true で撮影し、
  // ページ絶対座標で切り抜く（この撮影でブラウザがスクロール位置をリセットするため、
  // 元の位置への復元は content.js 側で撮影直後に行う）
  const m = await cdp(tabId, 'Page.getLayoutMetrics');
  const cs = m.cssContentSize || m.contentSize;
  const pageW = Math.max(1, Math.ceil(cs.width));
  const pageH = Math.max(1, Math.ceil(cs.height));

  const crop = clampRect(pageRect, pageW, pageH);
  if (!crop) throw new Error('要素がページ範囲外です');
  const captureH = Math.min(pageH, Math.ceil(crop.y + crop.height));
  if (captureH > CONFIG.maxCaptureCssHeight) {
    throw new Error(`要素がページ上端から ${CONFIG.maxCaptureCssHeight}px 以上下にあるため撮影できません`);
  }

  const { data } = await cdp(tabId, 'Page.captureScreenshot', {
    format: 'png',
    captureBeyondViewport: true,
    fromSurface: true,
    clip: { x: 0, y: 0, width: pageW, height: captureH, scale: 1 },
  });

  const res = await cropOnOffscreen({
    base64: data,
    sourceCss: { w: pageW, h: captureH },
    crop,
    strict: true,
  });
  if (res && res.mismatch) {
    throw new Error('このページでは画面外を含む撮影ができません。要素を画面内に収めてから撮影してください');
  }
  return res;
}

async function cropOnOffscreen(payload) {
  const targetWidth = CONFIG.outputScale
    ? Math.max(1, Math.round(payload.crop.width * CONFIG.outputScale))
    : null;
  await ensureOffscreen();
  const res = await chrome.runtime.sendMessage({
    target: 'offscreen',
    type: 'crop-copy',
    targetWidth,
    ...payload,
  });
  if (!res) throw new Error('offscreen から応答がありません');
  // res.ok === false かつ res.base64 あり → content 側でクリップボード書き込みを再試行
  return res;
}

function clampRect(r, maxW, maxH) {
  const x0 = Math.max(0, r.x);
  const y0 = Math.max(0, r.y);
  const x1 = Math.min(maxW, r.x + r.width);
  const y1 = Math.min(maxH, r.y + r.height);
  if (x1 - x0 < 1 || y1 - y0 < 1) return null;
  return { x: x0, y: y0, width: x1 - x0, height: y1 - y0 };
}

/** Base64 PNG の先頭（IHDR）だけをデコードして幅・高さを得る */
function pngSizeFromBase64(b64) {
  const bin = atob(b64.slice(0, 44));
  const u32 = (o) =>
    ((bin.charCodeAt(o) << 24) | (bin.charCodeAt(o + 1) << 16) |
     (bin.charCodeAt(o + 2) << 8) | bin.charCodeAt(o + 3)) >>> 0;
  return { width: u32(16), height: u32(20) };
}

/* ============================================================
 * debugger 接続（クリック時のみ・撮影後すぐ切断）
 * ============================================================ */
function ensureAttached(tabId) {
  const existing = attached.get(tabId);
  if (existing) return existing.ready;

  const entry = { ready: null, timer: 0 };
  entry.ready = (async () => {
    try {
      await chrome.debugger.attach({ tabId }, PROTOCOL_VERSION);
    } catch (e) {
      if (!/already attached/i.test(e?.message || '')) throw e;
      // Service Worker 再起動直後など、自分の接続が残っていればそのまま使う
      await cdp(tabId, 'Runtime.evaluate', { expression: '1' });
    }
  })();
  entry.ready.catch(() => {
    if (attached.get(tabId) === entry) {
      clearTimeout(entry.timer);
      attached.delete(tabId);
    }
  });
  // 撮影要求が来ないまま放置されても繋ぎっぱなしにならないよう安全タイマー
  entry.timer = setTimeout(() => detach(tabId), CONFIG.safetyDetachMs);
  attached.set(tabId, entry);
  return entry.ready;
}

async function detach(tabId) {
  const entry = attached.get(tabId);
  if (!entry) return;
  attached.delete(tabId);
  clearTimeout(entry.timer);
  try {
    await entry.ready;
  } catch (_) {
    return; // アタッチ自体が失敗していた
  }
  await chrome.debugger.detach({ tabId }).catch(() => {});
}

chrome.debugger.onDetach.addListener((source) => {
  if (source.tabId == null) return;
  const entry = attached.get(source.tabId);
  if (entry) clearTimeout(entry.timer);
  attached.delete(source.tabId);
});

chrome.tabs.onRemoved.addListener((tabId) => {
  const entry = attached.get(tabId);
  if (entry) clearTimeout(entry.timer);
  attached.delete(tabId);
});

/* ============================================================
 * offscreen ドキュメント
 * ============================================================ */
let creatingOffscreen = null;

async function ensureOffscreen() {
  const url = chrome.runtime.getURL('offscreen.html');
  const ctx = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [url],
  });
  if (ctx.length) return;
  if (!creatingOffscreen) {
    creatingOffscreen = chrome.offscreen
      .createDocument({
        url: 'offscreen.html',
        reasons: ['CLIPBOARD'],
        justification: 'キャプチャした画像を切り抜いてクリップボードへコピーするため',
      })
      .catch((e) => {
        if (!/single offscreen|already/i.test(e?.message || '')) throw e;
      })
      .finally(() => {
        creatingOffscreen = null;
      });
  }
  await creatingOffscreen;
}

/* ============================================================
 * バッジ
 * ============================================================ */
function setBadge(tabId, text, color) {
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
  if (color) chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {});
}
