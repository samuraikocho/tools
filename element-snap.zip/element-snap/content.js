// content.js — ページ内のハイライト表示とマウス／キー操作の検知
// 要素の特定そのものは background (CDP) が行うため、Shadow DOM 内の要素も正確に選択できる。
(() => {
  'use strict';

  // 2回目以降の注入では既存インスタンスを再利用
  if (window.__elementSnap__) {
    window.__elementSnap__.start();
    return;
  }

  const PORT_NAME = 'element-snap';
  const BLOCKED_EVENTS = ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'dblclick', 'auxclick'];

  let state = 'idle'; // 'idle' | 'selecting' | 'busy'
  let port = null;

  // UI
  let host = null, wrap = null, box = null, labelEl = null, hintEl = null, toastEl = null;
  let cursorStyle = null;
  let teardownTimer = 0;

  // ホバー要求のスロットリング（同時に1リクエストのみ）
  let seq = 0;
  let inflight = false;
  let inflightTimer = 0;
  let pending = false;
  let lastX = 0, lastY = 0, hasPoint = false;
  let wheelTimer = 0;

  /* ---------------- ライフサイクル ---------------- */
  function start() {
    if (state !== 'idle') return;
    destroyUI(); // 前回のトーストが残っていれば即片付け

    try {
      port = chrome.runtime.connect({ name: PORT_NAME });
    } catch (e) {
      console.warn('[ElementSnap] 接続できません', e);
      return;
    }
    port.onMessage.addListener(onPortMessage);
    port.onDisconnect.addListener(() => {
      port = null;
      if (state !== 'idle') finish(false, '拡張機能との接続が切れました');
    });

    state = 'selecting';
    seq = 0;
    inflight = pending = hasPoint = false;
    buildUI();
    addListeners();
  }

  function stop() {
    removeListeners();
    destroyUI();
    disconnect();
    state = 'idle';
  }

  function finish(ok, message) {
    removeListeners();
    disconnect();
    state = 'idle';
    if (!host) return;
    box.style.display = 'none';
    hintEl.style.display = 'none';
    wrap.style.visibility = 'visible';
    showToast(message, ok ? 'ok' : 'err');
    teardownTimer = setTimeout(destroyUI, ok ? 1600 : 3500);
  }

  function disconnect() {
    if (port) {
      try { port.disconnect(); } catch (_) {}
      port = null;
    }
  }

  function send(msg) {
    if (!port) return;
    try { port.postMessage(msg); } catch (_) {}
  }

  /* ---------------- UI ---------------- */
  const CSS = `
    .wrap { position: fixed; inset: 0; pointer-events: none;
            font: 12px/1.4 "Segoe UI", "Yu Gothic UI", Meiryo, system-ui, sans-serif; }
    .wrap * { pointer-events: none; box-sizing: border-box; }
    .box { position: fixed; display: none; border: 2px solid #0b6cff;
           background: rgba(11, 108, 255, .12); border-radius: 2px;
           box-shadow: 0 0 0 1px rgba(255,255,255,.6); }
    .label { position: absolute; left: -2px; bottom: 100%; margin-bottom: 2px;
             background: #0b6cff; color: #fff; padding: 2px 6px; border-radius: 3px;
             white-space: nowrap; max-width: 70vw; overflow: hidden; text-overflow: ellipsis; }
    .label.inside { bottom: auto; top: 0; left: 0; margin: 0; border-radius: 0 0 3px 0; }
    .hint { position: fixed; top: 10px; left: 50%; transform: translateX(-50%);
            background: rgba(32, 33, 36, .92); color: #fff; padding: 6px 12px; border-radius: 6px;
            box-shadow: 0 2px 8px rgba(0,0,0,.3); white-space: nowrap; }
    .hint b { color: #8ab4f8; font-weight: 600; }
    .toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
             padding: 8px 16px; border-radius: 6px; color: #fff; background: #202124;
             box-shadow: 0 2px 10px rgba(0,0,0,.35); display: none; max-width: 80vw; }
    .toast.ok { background: #137333; }
    .toast.err { background: #c5221f; }
  `;

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    return e;
  }

  function buildUI() {
    host = document.createElement('element-snap-overlay');
    host.setAttribute('style', [
      'all: initial',
      'position: fixed !important', 'inset: 0 !important',
      'width: 100vw !important', 'height: 100vh !important',
      'margin: 0 !important', 'padding: 0 !important', 'border: 0 !important',
      'background: transparent !important', 'overflow: visible !important',
      'display: block !important', 'pointer-events: none !important',
      'z-index: 2147483647 !important',
    ].join(';'));

    const root = host.attachShadow({ mode: 'closed' });
    const style = el('style');
    style.textContent = CSS;

    wrap = el('div', 'wrap');
    box = el('div', 'box');
    labelEl = el('div', 'label');
    box.appendChild(labelEl);

    hintEl = el('div', 'hint');
    hintEl.append(
      el('b', null, 'クリック'), ' でコピー　',
      el('b', null, '↑/↓'), ' 親/子要素　',
      el('b', null, 'Enter'), ' 確定　',
      el('b', null, 'Esc'), ' 終了'
    );
    toastEl = el('div', 'toast');

    wrap.append(box, hintEl, toastEl);
    root.append(style, wrap);
    document.documentElement.appendChild(host);

    // 可能ならトップレイヤーに置き、モーダル等より前面に表示
    try {
      host.popover = 'manual';
      host.showPopover();
    } catch (_) {}

    cursorStyle = document.createElement('style');
    cursorStyle.textContent = '* { cursor: crosshair !important; }';
    document.documentElement.appendChild(cursorStyle);
  }

  function destroyUI() {
    clearTimeout(teardownTimer);
    if (cursorStyle) { cursorStyle.remove(); cursorStyle = null; }
    if (host) { host.remove(); host = null; }
    wrap = box = labelEl = hintEl = toastEl = null;
  }

  function render(rect, label) {
    if (!box) return;
    if (!rect || rect.width <= 0 || rect.height <= 0) {
      box.style.display = 'none';
      return;
    }
    box.style.display = 'block';
    box.style.left = rect.x + 'px';
    box.style.top = rect.y + 'px';
    box.style.width = rect.width + 'px';
    box.style.height = rect.height + 'px';
    labelEl.textContent = `${label || ''}  ${Math.round(rect.width)} × ${Math.round(rect.height)}`;
    labelEl.classList.toggle('inside', rect.y < 22);
  }

  function showToast(text, kind) {
    if (!toastEl) return;
    toastEl.textContent = text;
    toastEl.className = 'toast' + (kind ? ' ' + kind : '');
    toastEl.style.display = 'block';
  }

  /* ---------------- イベント ---------------- */
  function addListeners() {
    window.addEventListener('mousemove', onMove, { capture: true, passive: true });
    window.addEventListener('mouseout', onOut, { capture: true, passive: true });
    window.addEventListener('scroll', onScroll, { capture: true, passive: true });
    window.addEventListener('wheel', onWheel, { capture: true, passive: true });
    window.addEventListener('resize', onScroll, { passive: true });
    window.addEventListener('keydown', onKey, true);
    window.addEventListener('click', onClick, true);
    for (const t of BLOCKED_EVENTS) window.addEventListener(t, block, true);
  }

  function removeListeners() {
    window.removeEventListener('mousemove', onMove, true);
    window.removeEventListener('mouseout', onOut, true);
    window.removeEventListener('scroll', onScroll, true);
    window.removeEventListener('wheel', onWheel, true);
    window.removeEventListener('resize', onScroll);
    window.removeEventListener('keydown', onKey, true);
    window.removeEventListener('click', onClick, true);
    for (const t of BLOCKED_EVENTS) window.removeEventListener(t, block, true);
    clearTimeout(inflightTimer);
    clearTimeout(wheelTimer);
  }

  // ページ側（Salesforce 等）のクリック処理・フォーカス移動を抑止
  function block(e) {
    if (e.button !== undefined && e.button !== 0) return; // 左ボタン以外は通す
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
  }

  function onClick(e) {
    if (e.button !== 0) return;
    block(e);
    if (state === 'selecting') capture(e.clientX, e.clientY);
  }

  function onMove(e) {
    lastX = e.clientX;
    lastY = e.clientY;
    hasPoint = true;
    requestHover();
  }

  function onOut(e) {
    if (!e.relatedTarget) { // ウィンドウ外へ出た
      hasPoint = false;
      render(null);
    }
  }

  function onScroll() { requestHover(); }

  function onWheel() {
    // Shadow DOM 内のスクロールは scroll イベントが届かないため wheel で補完
    clearTimeout(wheelTimer);
    wheelTimer = setTimeout(requestHover, 60);
  }

  function onKey(e) {
    if (state === 'idle') return;
    const k = e.key;
    if (k === 'Escape') {
      block(e);
      stop();
      return;
    }
    if (state !== 'selecting') return;
    if (k === 'ArrowUp' || k === 'w' || k === 'W') {
      block(e);
      send({ type: 'parent', seq: ++seq });
    } else if (k === 'ArrowDown' || k === 's' || k === 'S') {
      block(e);
      send({ type: 'child', seq: ++seq });
    } else if (k === 'Enter') {
      block(e);
      capture(lastX, lastY);
    }
  }

  /* ---------------- ホバー問い合わせ ---------------- */
  function requestHover() {
    if (!hasPoint) return;
    pending = true;
    pump();
  }

  function pump() {
    if (inflight || !pending || state !== 'selecting') return;
    pending = false;
    inflight = true;
    send({ type: 'hover', seq: ++seq, x: lastX, y: lastY, sx: window.scrollX, sy: window.scrollY });
    clearTimeout(inflightTimer);
    inflightTimer = setTimeout(() => { inflight = false; pump(); }, 800); // 応答喪失時の保険
  }

  /* ---------------- キャプチャ ---------------- */
  const nextFrames = () =>
    new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

  async function capture(x, y) {
    if (state !== 'selecting') return;
    state = 'busy';
    pending = false;
    // オーバーレイが写り込まないよう非表示にし、描画反映を待ってからキャプチャ要求
    if (wrap) wrap.style.visibility = 'hidden';
    await nextFrames();
    send({ type: 'capture', x, y, sx: window.scrollX, sy: window.scrollY });
  }

  async function fallbackWrite(m) {
    try {
      const bytes = b64ToBytes(m.base64);
      const { width, height } = pngSize(bytes);
      const blob = new Blob([bytes], { type: 'image/png' });
      window.focus();
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      finish(true, `コピーしました（${width} × ${height} px）`);
    } catch (e) {
      finish(false, 'クリップボードへの書き込みに失敗しました: ' + (e.message || e));
    }
  }

  /* ---------------- background からのメッセージ ---------------- */
  function onPortMessage(m) {
    switch (m.type) {
      case 'highlight':
        if (m.kind === 'hover') {
          inflight = false;
          clearTimeout(inflightTimer);
        }
        if (m.seq === seq && state === 'selecting') render(m.rect, m.label);
        if (m.kind === 'hover') pump();
        break;
      case 'captured':
        if (wrap) {
          box.style.display = 'none';
          hintEl.style.display = 'none';
          wrap.style.visibility = 'visible';
        }
        showToast('クリップボードにコピー中…');
        break;
      case 'result':
        if (m.ok) finish(true, `コピーしました（${m.width} × ${m.height} px）`);
        else finish(false, 'キャプチャに失敗しました: ' + m.error);
        break;
      case 'clipboard-fallback':
        fallbackWrite(m);
        break;
      case 'error':
        finish(false, m.message);
        break;
      case 'stop':
        stop();
        break;
    }
  }

  /* ---------------- ユーティリティ ---------------- */
  function b64ToBytes(b64) {
    const bin = atob(b64);
    const u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return u8;
  }

  function pngSize(u8) {
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    return { width: dv.getUint32(16), height: dv.getUint32(20) };
  }

  window.__elementSnap__ = { start, stop };
  start();
})();
