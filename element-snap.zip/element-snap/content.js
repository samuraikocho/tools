// content.js (v1.2) — Shadow DOM 対応の最小要素ヒットテスト / ハイライト / 座標計算 / スクロール位置の維持
// ホバー判定は debugger を使わずページ内で行うため、選択中にデバッグ警告バーは出ない。
(() => {
  'use strict';

  // 2回目以降の注入はトグル（開始 / 終了）
  if (window.__elementSnap12__) {
    window.__elementSnap12__.toggle();
    return;
  }

  const CONFIG = {
    // 要素内のテキスト部分だけを選択対象にする（ボタン・リンク等の中のテキストは除外）
    textTargets: true,
    // デバッグ警告バーの表示でビューポートの高さが変わるのを待つ最大時間（ms）
    infobarWaitMaxMs: 800,
  };

  const BLOCKED_EVENTS = ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'dblclick', 'auxclick'];
  const INTERACTIVE =
    'button,a,input,select,textarea,label,summary,option,' +
    '[role="button"],[role="link"],[role="menuitem"],[role="tab"],[role="option"],[role="checkbox"]';

  /* ============================================================
   * Shadow DOM ヘルパー
   * ============================================================ */
  // closed な shadowRoot も content script からは chrome.dom.openOrClosedShadowRoot で取得できる
  function getShadow(el) {
    if (el.shadowRoot) return el.shadowRoot;
    try {
      return chrome.dom?.openOrClosedShadowRoot?.(el) || null;
    } catch (_) {
      return null;
    }
  }

  const composedParent = (n) =>
    n.parentElement || (n.parentNode && n.parentNode.host) || null;

  /** Shadow DOM を再帰的に潜って、座標直下の最前面の要素を返す */
  function deepElementFromPoint(x, y) {
    let el = document.elementFromPoint(x, y);
    for (let depth = 0; el && depth < 64; depth++) {
      const sr = getShadow(el);
      if (!sr) break;
      const inner = sr.elementFromPoint(x, y);
      if (!inner || inner === el) break;
      el = inner;
    }
    return el;
  }

  /** 描画上の子要素（shadowRoot の中身、slot の割り当て先、display:contents を展開） */
  function renderedChildren(el, out = []) {
    const sr = getShadow(el);
    const kids =
      sr ? sr.children :
      el.localName === 'slot' ? el.assignedElements({ flatten: true }) :
      el.children;
    for (const k of kids) {
      if (k === host || k.localName === 'style' || k.localName === 'script') continue;
      if (k.localName === 'slot' || getComputedStyle(k).display === 'contents') {
        renderedChildren(k, out);
      } else {
        out.push(k);
      }
    }
    return out;
  }

  const containsPt = (r, x, y) =>
    r.width > 0 && r.height > 0 && x >= r.left && x < r.right && y >= r.top && y < r.bottom;

  function isVisible(el) {
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none' && parseFloat(cs.opacity) > 0.01;
  }

  /**
   * elementFromPoint は pointer-events:none の要素（アイコン・ラベル内の span 等）を飛ばして
   * 親を返すことがあるため、座標を含む可視の子孫へさらに降りて最小の要素を特定する。
   */
  function refineToSmallest(el, x, y) {
    for (let depth = 0; depth < 32; depth++) {
      if (el instanceof SVGElement) break; // SVG 内部（path 等）までは降りない
      const kids = renderedChildren(el);
      let next = null;
      for (let i = kids.length - 1; i >= 0; i--) { // 後ろの兄弟ほど手前に描画される
        const k = kids[i];
        if (!containsPt(k.getBoundingClientRect(), x, y)) continue;
        if (!isVisible(k)) continue;
        next = k;
        break;
      }
      if (!next) break;
      el = next;
    }
    return el;
  }

  function isInteractive(el) {
    for (let n = el, i = 0; n && i < 4; n = composedParent(n), i++) {
      if (n.matches && n.matches(INTERACTIVE)) return true;
    }
    return false;
  }

  /** 要素直下のテキストノードのうち、座標を含み、要素より十分小さいものを返す */
  function textAt(el, x, y) {
    if (!CONFIG.textTargets || isInteractive(el)) return null;
    const er = el.getBoundingClientRect();
    const elArea = er.width * er.height;
    const range = document.createRange();
    for (const n of el.childNodes) {
      if (n.nodeType !== 3 || !n.nodeValue.trim()) continue;
      range.selectNodeContents(n);
      for (const r of range.getClientRects()) {
        if (!containsPt(r, x, y)) continue;
        const b = range.getBoundingClientRect();
        if (b.width * b.height < elArea * 0.5) return n;
        return null;
      }
    }
    return null;
  }

  /** マウス位置の最小ターゲット（Element または Text） */
  function hitTest(x, y) {
    let el = deepElementFromPoint(x, y);
    if (!el || el === host) return null;
    el = refineToSmallest(el, x, y);
    return textAt(el, x, y) || el;
  }

  function rectOf(node) {
    if (!node || !node.isConnected) return null;
    if (node.nodeType === 3) {
      const range = document.createRange();
      range.selectNodeContents(node);
      return range.getBoundingClientRect();
    }
    return node.getBoundingClientRect();
  }

  /** ↑キー用: 表示上の親（display:contents はスキップ） */
  function visualParent(node) {
    let p = composedParent(node);
    while (p && p !== document.documentElement && getComputedStyle(p).display === 'contents') {
      p = composedParent(p);
    }
    return p;
  }

  /* ============================================================
   * 状態
   * ============================================================ */
  let state = 'idle'; // 'idle' | 'selecting' | 'busy'
  let host = null, wrap = null, box = null, labelEl = null, hintEl = null, toastEl = null;
  let cursorStyle = null, toastTimer = 0;
  let hovered = null, current = null, stack = [];
  let lastX = 0, lastY = 0, hasPoint = false, rafId = 0;

  /* ============================================================
   * ライフサイクル
   * ============================================================ */
  function toggle() {
    if (state === 'idle') start();
    else if (state === 'selecting') stop();
  }

  function start() {
    destroyUI();
    state = 'selecting';
    hovered = current = null;
    stack = [];
    hasPoint = false;
    buildUI();
    addListeners();
    notify({ type: 'mode', on: true });
  }

  function stop() {
    removeListeners();
    destroyUI();
    state = 'idle';
    notify({ type: 'mode', on: false });
  }

  function finish(ok, message) {
    removeListeners();
    state = 'idle';
    notify({ type: 'mode', on: false });
    if (!host) return;
    box.style.display = 'none';
    hintEl.style.display = 'none';
    wrap.style.visibility = 'visible';
    showToast(message, ok ? 'ok' : 'err');
    toastTimer = setTimeout(destroyUI, ok ? 1500 : 3500);
  }

  function notify(msg) {
    try { chrome.runtime.sendMessage(msg).catch(() => {}); } catch (_) {}
  }

  async function call(msg) {
    const res = await chrome.runtime.sendMessage(msg);
    if (!res) throw new Error('拡張機能から応答がありません');
    if (res.ok === false && !res.base64) throw new Error(res.error || '不明なエラー');
    return res;
  }

  /* ============================================================
   * UI（closed Shadow DOM・pointer-events:none でヒットテスト対象外）
   * ============================================================ */
  const CSS = `
    .wrap { position: fixed; inset: 0; pointer-events: none;
            font: 12px/1.4 "Segoe UI", "Yu Gothic UI", Meiryo, system-ui, sans-serif; }
    .wrap * { pointer-events: none; box-sizing: border-box; }
    .box { position: fixed; display: none; border: 2px solid #0b6cff;
           background: rgba(11,108,255,.12); border-radius: 2px;
           box-shadow: 0 0 0 1px rgba(255,255,255,.6); }
    .label { position: absolute; left: -2px; bottom: 100%; margin-bottom: 2px;
             background: #0b6cff; color: #fff; padding: 2px 6px; border-radius: 3px;
             white-space: nowrap; max-width: 70vw; overflow: hidden; text-overflow: ellipsis; }
    .label.inside { bottom: auto; top: 100%; margin: 2px 0 0; }
    .hint { position: fixed; top: 10px; left: 50%; transform: translateX(-50%);
            background: rgba(32,33,36,.92); color: #fff; padding: 6px 12px; border-radius: 6px;
            box-shadow: 0 2px 8px rgba(0,0,0,.3); white-space: nowrap; }
    .hint b { color: #8ab4f8; font-weight: 600; }
    .toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
             padding: 8px 16px; border-radius: 6px; color: #fff; background: #202124;
             box-shadow: 0 2px 10px rgba(0,0,0,.35); display: none; max-width: 80vw; }
    .toast.ok { background: #137333; }
    .toast.err { background: #c5221f; }
  `;

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    return e;
  }

  function buildUI() {
    host = document.createElement('element-snap-overlay');
    host.setAttribute('style', [
      'all: initial',
      'position: fixed !important', 'inset: 0 !important',
      'width: 100vw !important', 'height: 100vh !important',
      'margin: 0 !important', 'padding: 0 !important', 'border: 0 !important',
      'background: transparent !important', 'overflow: visible !important',
      'display: block !important', 'pointer-events: none !important',
      'z-index: 2147483647 !important',
    ].join(';'));

    const root = host.attachShadow({ mode: 'closed' });
    const style = el('style');
    style.textContent = CSS;
    wrap = el('div', 'wrap');
    box = el('div', 'box');
    labelEl = el('div', 'label');
    box.appendChild(labelEl);
    hintEl = el('div', 'hint');
    hintEl.append(
      el('b', null, 'クリック'), ' でコピー　',
      el('b', null, '↑/↓'), ' 親/子要素　',
      el('b', null, 'Enter'), ' 確定　',
      el('b', null, 'Esc'), ' 終了'
    );
    toastEl = el('div', 'toast');
    wrap.append(box, hintEl, toastEl);
    root.append(style, wrap);
    document.documentElement.appendChild(host);

    try {
      host.popover = 'manual'; // トップレイヤーに置いてモーダル等より前面へ
      host.showPopover();
    } catch (_) {}

    cursorStyle = document.createElement('style');
    cursorStyle.textContent = '* { cursor: crosshair !important; }';
    document.documentElement.appendChild(cursorStyle);
  }

  function destroyUI() {
    clearTimeout(toastTimer);
    if (cursorStyle) { cursorStyle.remove(); cursorStyle = null; }
    if (host) { host.remove(); host = null; }
    wrap = box = labelEl = hintEl = toastEl = null;
  }

  function describe(node) {
    if (node.nodeType === 3) {
      const t = node.nodeValue.trim().replace(/\s+/g, ' ');
      return `#text "${t.length > 24 ? t.slice(0, 23) + '…' : t}"`;
    }
    let t = node.localName;
    if (node.id) t += '#' + node.id;
    const cls = typeof node.className === 'string' ? node.className.trim() : '';
    if (cls) t += cls.split(/\s+/).slice(0, 3).map((c) => '.' + c).join('');
    return t.length > 80 ? t.slice(0, 79) + '…' : t;
  }

  function render() {
    if (!box) return;
    const r = rectOf(current);
    if (!r || r.width <= 0 || r.height <= 0) {
      box.style.display = 'none';
      return;
    }
    box.style.display = 'block';
    box.style.left = r.left + 'px';
    box.style.top = r.top + 'px';
    box.style.width = r.width + 'px';
    box.style.height = r.height + 'px';
    labelEl.textContent = `${describe(current)}  ${Math.round(r.width)} × ${Math.round(r.height)}`;
    labelEl.classList.toggle('inside', r.top < 22);
  }

  function showToast(text, kind) {
    if (!toastEl) return;
    toastEl.textContent = text;
    toastEl.className = 'toast' + (kind ? ' ' + kind : '');
    toastEl.style.display = 'block';
  }

  /* ============================================================
   * イベント
   * ============================================================ */
  function addListeners() {
    window.addEventListener('mousemove', onMove, { capture: true, passive: true });
    window.addEventListener('mouseout', onOut, { capture: true, passive: true });
    window.addEventListener('scroll', scheduleUpdate, { capture: true, passive: true });
    window.addEventListener('wheel', scheduleUpdate, { capture: true, passive: true });
    window.addEventListener('resize', scheduleUpdate, { passive: true });
    window.addEventListener('keydown', onKey, true);
    window.addEventListener('click', onClick, true);
    for (const t of BLOCKED_EVENTS) window.addEventListener(t, block, true);
  }

  function removeListeners() {
    window.removeEventListener('mousemove', onMove, true);
    window.removeEventListener('mouseout', onOut, true);
    window.removeEventListener('scroll', scheduleUpdate, true);
    window.removeEventListener('wheel', scheduleUpdate, true);
    window.removeEventListener('resize', scheduleUpdate);
    window.removeEventListener('keydown', onKey, true);
    window.removeEventListener('click', onClick, true);
    for (const t of BLOCKED_EVENTS) window.removeEventListener(t, block, true);
    cancelAnimationFrame(rafId);
    rafId = 0;
  }

  // ページ側のクリック処理・フォーカス移動を抑止（左ボタンのみ）
  function block(e) {
    if (e.button !== undefined && e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
  }

  function onClick(e) {
    if (e.button !== 0) return;
    block(e);
    if (state !== 'selecting') return;
    // クリック位置で判定し直してから撮影（ホバー更新が間に合っていない場合でも正確に）
    lastX = e.clientX;
    lastY = e.clientY;
    hasPoint = true;
    const t = hitTest(lastX, lastY);
    if (t && t !== hovered) {
      hovered = current = t;
      stack = [];
    }
    capture();
  }

  function onMove(e) {
    lastX = e.clientX;
    lastY = e.clientY;
    hasPoint = true;
    scheduleUpdate();
  }

  function onOut(e) {
    if (!e.relatedTarget) {
      hasPoint = false;
      hovered = current = null;
      render();
    }
  }

  function scheduleUpdate() {
    if (rafId || state !== 'selecting') return;
    rafId = requestAnimationFrame(() => {
      rafId = 0;
      if (state !== 'selecting') return;
      if (hasPoint) {
        const t = hitTest(lastX, lastY);
        if (t !== hovered) { // マウス直下が変わった時だけ選択をリセット（↑で選んだ親を保持）
          hovered = current = t;
          stack = [];
        }
      }
      render();
    });
  }

  function onKey(e) {
    if (state !== 'selecting') {
      if (state === 'busy' && e.key === 'Escape') block(e);
      return;
    }
    const k = e.key;
    if (k === 'Escape') {
      block(e);
      stop();
    } else if ((k === 'ArrowUp' || k === 'w' || k === 'W') && current) {
      block(e);
      const p = visualParent(current);
      if (p && p !== document.documentElement) {
        stack.push(current);
        current = p;
        render();
      }
    } else if ((k === 'ArrowDown' || k === 's' || k === 'S') && stack.length) {
      block(e);
      current = stack.pop();
      render();
    } else if (k === 'Enter') {
      block(e);
      capture();
    }
  }

  /* ============================================================
   * キャプチャ
   * ============================================================ */
  const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));
  const frames = () => nextFrame().then(nextFrame);

  /**
   * debugger のアタッチでデバッグ警告バーが表示されるとビューポートの高さが変わり、
   * 要素の位置もずれる。高さが落ち着くのを待ってから座標を測る。
   */
  async function waitViewportStable() {
    const t0 = performance.now();
    let lastH = window.innerHeight;
    let lastW = window.innerWidth;
    let changedAt = t0;
    for (;;) {
      await nextFrame();
      const now = performance.now();
      if (window.innerHeight !== lastH || window.innerWidth !== lastW) {
        lastH = window.innerHeight;
        lastW = window.innerWidth;
        changedAt = now;
      }
      if (now - changedAt >= 120 && now - t0 >= 150) return;
      if (now - t0 >= CONFIG.infobarWaitMaxMs) return;
    }
  }

  /** 撮影前のスクロール位置（ページ全体 + 祖先のスクロールコンテナ）を記録し、復元関数を返す */
  function saveScrollPositions(target) {
    const saved = [];
    for (let n = composedParent(target); n; n = composedParent(n)) {
      if (n === document.documentElement || n === document.body) continue;
      if (n.scrollHeight > n.clientHeight || n.scrollWidth > n.clientWidth) {
        saved.push([n, n.scrollTop, n.scrollLeft]);
      }
    }
    const wx = window.scrollX;
    const wy = window.scrollY;
    return () => {
      for (let i = saved.length - 1; i >= 0; i--) {
        const [n, t, l] = saved[i];
        if (n.scrollTop !== t || n.scrollLeft !== l) {
          n.scrollTo({ top: t, left: l, behavior: 'instant' });
        }
      }
      if (window.scrollX !== wx || window.scrollY !== wy) {
        window.scrollTo({ top: wy, left: wx, behavior: 'instant' });
      }
    };
  }

  async function capture() {
    if (state !== 'selecting' || !current || !current.isConnected) return;
    const target = current;
    state = 'busy';
    if (wrap) wrap.style.visibility = 'hidden'; // ハイライトの写り込み防止

    // ★ 撮影前のスクロール位置を記録（撮影後、必ず元に戻す）
    const restoreScroll = saveScrollPositions(target);
    try {
      // ★ クリックの瞬間にだけ debugger をアタッチ
      await call({ type: 'attach' });
      await waitViewportStable();
      await frames();

      // 撮影直前の最新の位置で測る
      const r = rectOf(target);
      if (!r || r.width < 1 || r.height < 1) {
        throw new Error('要素のサイズを取得できません（非表示要素の可能性があります）');
      }
      const scrollX = window.scrollX;
      const scrollY = window.scrollY;
      const de = document.documentElement;

      const res = await call({
        type: 'capture',
        // ビューポート座標（画面内に収まる要素はこちらで切り抜く）
        viewRect: { x: r.left, y: r.top, width: r.width, height: r.height },
        // ページ全体の絶対座標 = ビューポート座標 + スクロール量（画面外にはみ出す要素用）
        pageRect: { x: r.left + scrollX, y: r.top + scrollY, width: r.width, height: r.height },
        scroll: { x: scrollX, y: scrollY },
        viewport: {
          w: window.innerWidth,
          h: window.innerHeight,
          cw: de.clientWidth || window.innerWidth,   // スクロールバーを除いた表示幅
          ch: de.clientHeight || window.innerHeight, // スクロールバーを除いた表示高さ
        },
        dpr: window.devicePixelRatio || 1,
      });
      restoreScroll(); // background 側では撮影直後に debugger が切断済み

      if (!res.ok && res.base64) {
        // offscreen はフォーカスを持てず書き込みに失敗する環境がある → ページ側で再試行
        await writeClipboardHere(res.base64);
      }
      finish(true, `コピーしました（${res.width} × ${res.height} px）`);
    } catch (e) {
      notify({ type: 'detach' });
      restoreScroll();
      finish(false, 'キャプチャ失敗: ' + (e.message || e));
    }
  }

  async function writeClipboardHere(b64) {
    const bin = atob(b64);
    const u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    window.focus();
    await navigator.clipboard.write([
      new ClipboardItem({ 'image/png': new Blob([u8], { type: 'image/png' }) }),
    ]);
  }

  window.__elementSnap12__ = { toggle };
  start();
})();
